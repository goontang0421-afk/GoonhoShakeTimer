plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "tv.goonho.shaketimer"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    defaultConfig {
        applicationId = "tv.goonho.shaketimer"
        minSdk = 30
        targetSdk = 35
        versionCode = 8
        versionName = "8.0"
    }
    buildFeatures { compose = true }
}

dependencies {
    implementation(project(":shared"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.wear.compose:compose-material:1.4.1")
    implementation("androidx.compose.foundation:foundation:1.7.6")
    implementation("com.google.android.gms:play-services-wearable:20.0.1")
}


