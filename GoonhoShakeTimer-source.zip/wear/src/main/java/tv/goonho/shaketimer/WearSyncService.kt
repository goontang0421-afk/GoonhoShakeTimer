package tv.goonho.shaketimer

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService
import tv.goonho.shaketimer.shared.PresetStore
import tv.goonho.shaketimer.shared.TimerPreset
import tv.goonho.shaketimer.shared.TimerRuntimeStore
import tv.goonho.shaketimer.shared.AppSettings

class WearSyncService : WearableListenerService() {
    override fun onDataChanged(buffer: DataEventBuffer) {
        val runtime = TimerRuntimeStore(this)
        val presets = PresetStore(this)
        val settings = AppSettings(this)
        buffer.forEach { event ->
            if (event.type != DataEvent.TYPE_CHANGED) return@forEach
            val map = DataMapItem.fromDataItem(event.dataItem).dataMap
            when (event.dataItem.uri.path) {
                "/link_control" -> settings.setPhoneLinked(map.getBoolean("linked"))
                "/timer_state" -> {
                    if (!settings.phoneLinked()) return@forEach
                    runtime.setSelectedPreset(map.getInt("preset"))
                    if (map.getBoolean("running")) runtime.start(map.getLong("wall_started_at")) else runtime.stop()
                    ContextCompat.startForegroundService(this, Intent(this, ShakeTimerService::class.java).setAction(ShakeTimerService.ACTION_EXTERNAL_STATE))
                }
                "/presets" -> if (settings.phoneLinked()) repeat(4) { i ->
                    val current = presets.load()[i]
                    presets.save(i, TimerPreset(
                        map.getString("name_$i", current.name),
                        map.getInt("a_$i", current.firstSec),
                        map.getInt("b_$i", current.secondSec),
                        map.getInt("c_$i", current.thirdSec),
                    ))
                }
            }
        }
    }
}
