package tv.goonho.shaketimer

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import tv.goonho.shaketimer.shared.*

class ShakeTimerService : Service() {
    private lateinit var sensorManager: SensorManager
    private lateinit var detector: ShakeDetector
    private lateinit var presets: PresetStore
    private lateinit var runtime: TimerRuntimeStore
    private lateinit var settings: AppSettings
    private lateinit var alert: AlertPlayer
    private val handler = Handler(Looper.getMainLooper())
    private var lastAlertLevel = 0

    private val ticker = object : Runnable {
        override fun run() {
            if (runtime.isRunning()) {
                val preset = presets.load()[runtime.selectedPreset()]
                val elapsed = ((System.currentTimeMillis() - runtime.wallStartedAt()) / 1000L)
                    .coerceAtLeast(0L).toInt()
                val level = when {
                    elapsed >= preset.thirdSec -> 3
                    elapsed >= preset.secondSec -> 2
                    elapsed >= preset.firstSec -> 1
                    else -> 0
                }
                if (level > lastAlertLevel) {
                    alert.alert(level)
                    lastAlertLevel = level
                }
                broadcastState(elapsed)
                updateNotification(elapsed)
            } else {
                lastAlertLevel = 0
                broadcastState(0)
            }
            handler.postDelayed(this, 150L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        presets = PresetStore(this)
        runtime = TimerRuntimeStore(this)
        settings = AppSettings(this)
        alert = AlertPlayer(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        detector = ShakeDetector(
            thresholdG = settings.sensitivity().thresholdG,
            onShake = { toggleTimer(sync = true) }
        )
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(detector, it, SensorManager.SENSOR_DELAY_GAME)
        }
        createNotificationChannel()
        startAsForeground()
        handler.post(ticker)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> toggleTimer(sync = true)
            ACTION_STOP_TIMER -> stopTimer(sync = true)
            ACTION_REFRESH_SETTINGS -> detector.setThreshold(settings.sensitivity().thresholdG)
            ACTION_EXTERNAL_STATE -> {
                lastAlertLevel = 0
                broadcastState(currentElapsed())
            }
        }
        return START_STICKY
    }

    private fun toggleTimer(sync: Boolean) {
        if (runtime.isRunning()) runtime.stop() else runtime.start()
        lastAlertLevel = 0
        broadcastState(currentElapsed())
        if (sync) syncState()
    }

    private fun stopTimer(sync: Boolean) {
        runtime.stop()
        lastAlertLevel = 0
        broadcastState(0)
        if (sync) syncState()
    }

    private fun currentElapsed(): Int = if (!runtime.isRunning()) 0 else
        ((System.currentTimeMillis() - runtime.wallStartedAt()) / 1000L).coerceAtLeast(0L).toInt()

    private fun syncState() {
        val req = PutDataMapRequest.create("/timer_state").apply {
            dataMap.putBoolean("running", runtime.isRunning())
            dataMap.putLong("wall_started_at", if (runtime.isRunning()) runtime.wallStartedAt() else 0L)
            dataMap.putInt("preset", runtime.selectedPreset())
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    private fun broadcastState(elapsed: Int) {
        sendBroadcast(Intent(ACTION_STATE_CHANGED).setPackage(packageName).apply {
            putExtra("running", runtime.isRunning())
            putExtra("elapsed", elapsed)
            putExtra("preset", runtime.selectedPreset())
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "타이머 실행", NotificationManager.IMPORTANCE_LOW).apply {
                description = "화면이 꺼져 있어도 손목 흔들기를 감지합니다."
                setSound(null, null)
                enableVibration(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(elapsed: Int = currentElapsed()): Notification {
        val preset = presets.load()[runtime.selectedPreset()]
        val content = if (runtime.isRunning()) "%02d:%02d · %s".format(elapsed / 60, elapsed % 60, preset.name)
        else "손목을 흔들면 타이머가 시작됩니다"
        val launch = PendingIntent.getActivity(
            this, 0, Intent(this, WearMainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("군호 흔들기 타이머")
            .setContentText(content)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(launch)
            .build()
    }

    private fun startAsForeground() {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification())
        }
    }

    private fun updateNotification(elapsed: Int) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(elapsed))
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        sensorManager.unregisterListener(detector)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_TOGGLE = "tv.goonho.shaketimer.TOGGLE"
        const val ACTION_STOP_TIMER = "tv.goonho.shaketimer.STOP_TIMER"
        const val ACTION_REFRESH_SETTINGS = "tv.goonho.shaketimer.REFRESH_SETTINGS"
        const val ACTION_EXTERNAL_STATE = "tv.goonho.shaketimer.EXTERNAL_STATE"
        const val ACTION_STATE_CHANGED = "tv.goonho.shaketimer.STATE_CHANGED"
        private const val CHANNEL_ID = "shake_timer_service"
        private const val NOTIFICATION_ID = 3501
    }
}
