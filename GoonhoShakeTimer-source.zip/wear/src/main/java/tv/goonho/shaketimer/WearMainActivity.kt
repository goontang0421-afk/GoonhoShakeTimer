package tv.goonho.shaketimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.Text
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import tv.goonho.shaketimer.shared.*

class WearMainActivity : ComponentActivity() {
    private lateinit var store: PresetStore
    private lateinit var runtime: TimerRuntimeStore
    private lateinit var settings: AppSettings

    private val running = mutableStateOf(false)
    private val elapsed = mutableIntStateOf(0)
    private val selected = mutableIntStateOf(0)
    private val presetsState = mutableStateOf<List<TimerPreset>>(emptyList())

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ShakeTimerService.ACTION_STATE_CHANGED) return
            running.value = intent.getBooleanExtra("running", false)
            elapsed.intValue = intent.getIntExtra("elapsed", 0)
            selected.intValue = intent.getIntExtra("preset", 0).coerceIn(0, 4)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = PresetStore(this)
        runtime = TimerRuntimeStore(this)
        settings = AppSettings(this)
        presetsState.value = store.load()
        selected.intValue = runtime.selectedPreset()
        running.value = runtime.isRunning()
        elapsed.intValue = currentElapsed()

        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 301)
        }
        ContextCompat.startForegroundService(this, Intent(this, ShakeTimerService::class.java))
        setContent { WatchApp() }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ShakeTimerService.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(stateReceiver, filter)
    }

    override fun onStop() {
        unregisterReceiver(stateReceiver)
        super.onStop()
    }

    private fun currentElapsed(): Int = if (!runtime.isRunning()) 0 else
        ((System.currentTimeMillis() - runtime.wallStartedAt()) / 1000L).coerceAtLeast(0L).toInt()

    private fun toggle() {
        ContextCompat.startForegroundService(this, Intent(this, ShakeTimerService::class.java).setAction(ShakeTimerService.ACTION_TOGGLE))
    }

    private fun selectPreset(index: Int) {
        selected.intValue = index.coerceIn(0, 4)
        runtime.setSelectedPreset(selected.intValue)
        syncState()
    }

    private fun syncState() {
        val req = PutDataMapRequest.create("/timer_state").apply {
            dataMap.putBoolean("running", runtime.isRunning())
            dataMap.putLong("wall_started_at", if (runtime.isRunning()) runtime.wallStartedAt() else 0L)
            dataMap.putInt("preset", runtime.selectedPreset())
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    private fun savePreset(index: Int, preset: TimerPreset) {
        store.save(index, preset)
        presetsState.value = store.load()
        val all = presetsState.value
        val req = PutDataMapRequest.create("/presets").apply {
            all.forEachIndexed { i, p ->
                dataMap.putString("name_$i", p.name)
                dataMap.putInt("a_$i", p.firstSec)
                dataMap.putInt("b_$i", p.secondSec)
                dataMap.putInt("c_$i", p.thirdSec)
            }
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    @Composable private fun WatchApp() {
        var page by remember { mutableIntStateOf(0) } // 0 timer, 1 preset edit, 2 sensitivity
        when (page) {
            1 -> PresetEditor(onBack = { page = 0 })
            2 -> SensitivityEditor(onBack = { page = 0 })
            else -> TimerScreen(onEdit = { page = 1 }, onSensitivity = { page = 2 })
        }
    }

    @Composable private fun TimerScreen(onEdit: () -> Unit, onSensitivity: () -> Unit) {
        val presets = presetsState.value.ifEmpty { Defaults.presets }
        val preset = presets[selected.intValue.coerceIn(presets.indices)]
        val stage = preset.stageAt(elapsed.intValue)
        val bg = when (stage) {
            Stage.NORMAL -> Color.Black
            Stage.FIRST -> Color(0xFFFFEB3B)
            Stage.SECOND -> Color(0xFFFF9800)
            Stage.THIRD -> Color(0xFFF44336)
        }
        val fg = if (stage == Stage.NORMAL) Color.White else Color.Black

        Box(Modifier.fillMaxSize().background(bg).padding(8.dp), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.timer_billiards_bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.24f
            )
            Text(
                "군호TV",
                color = fg.copy(alpha = 0.11f),
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.Center)
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("%02d:%02d".format(elapsed.intValue / 60, elapsed.intValue % 60), color = fg, fontSize = 42.sp, fontWeight = FontWeight.Black)
                Text("${preset.firstSec} · ${preset.secondSec} · ${preset.thirdSec}", color = fg, fontSize = 12.sp)
                Button(onClick = { toggle() }, modifier = Modifier.size(58.dp)) { Text(if (running.value) "정지" else "시작", fontSize = 12.sp) }
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    repeat(5) { i -> Button(onClick = { selectPreset(i) }, modifier = Modifier.size(28.dp)) { Text("${i + 1}", fontSize = 9.sp) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(onClick = onEdit, modifier = Modifier.height(32.dp)) { Text("시간", fontSize = 9.sp) }
                    Button(onClick = onSensitivity, modifier = Modifier.height(32.dp)) { Text("감도", fontSize = 9.sp) }
                }
            }
        }
    }

    @Composable private fun PresetEditor(onBack: () -> Unit) {
        val presets = presetsState.value.ifEmpty { Defaults.presets }
        val base = presets[selected.intValue]
        var a by remember(base) { mutableIntStateOf(base.firstSec) }
        var b by remember(base) { mutableIntStateOf(base.secondSec) }
        var c by remember(base) { mutableIntStateOf(base.thirdSec) }
        var field by remember { mutableIntStateOf(0) }
        val values = listOf(a, b, c)

        Box(Modifier.fillMaxSize().background(Color.Black).padding(8.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("프리셋 ${selected.intValue + 1}", fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    repeat(3) { i -> Button(onClick = { field = i }, modifier = Modifier.height(32.dp)) { Text("${i + 1}차", fontSize = 9.sp) } }
                }
                Text("${values[field]}초", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        when (field) { 0 -> a = (a - 1).coerceAtLeast(1); 1 -> b = (b - 1).coerceAtLeast(a + 1); 2 -> c = (c - 1).coerceAtLeast(b + 1) }
                    }, modifier = Modifier.size(42.dp)) { Text("−") }
                    Button(onClick = {
                        when (field) { 0 -> a = (a + 1).coerceAtMost(b - 1); 1 -> b = (b + 1).coerceAtMost(c - 1); 2 -> c += 1 }
                    }, modifier = Modifier.size(42.dp)) { Text("+") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(onClick = onBack, modifier = Modifier.height(32.dp)) { Text("취소", fontSize = 9.sp) }
                    Button(onClick = { savePreset(selected.intValue, TimerPreset(base.name, a, b, c)); onBack() }, modifier = Modifier.height(32.dp)) { Text("저장", fontSize = 9.sp) }
                }
            }
        }
    }

    @Composable private fun SensitivityEditor(onBack: () -> Unit) {
        var sensitivity by remember { mutableStateOf(settings.sensitivity()) }
        Box(Modifier.fillMaxSize().background(Color.Black).padding(10.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("흔들기 감도", fontSize = 16.sp)
                ShakeSensitivity.entries.forEach { item ->
                    Button(onClick = { sensitivity = item }, modifier = Modifier.fillMaxWidth(0.72f).height(36.dp)) {
                        Text(if (item == sensitivity) "✓ ${item.label}" else item.label, fontSize = 11.sp)
                    }
                }
                Button(onClick = {
                    settings.setSensitivity(sensitivity)
                    ContextCompat.startForegroundService(this@WearMainActivity, Intent(this@WearMainActivity, ShakeTimerService::class.java).setAction(ShakeTimerService.ACTION_REFRESH_SETTINGS))
                    onBack()
                }, modifier = Modifier.height(34.dp)) { Text("저장", fontSize = 10.sp) }
            }
        }
    }
}

