package tv.goonho.shaketimer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.Text
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import tv.goonho.shaketimer.shared.*

class WearMainActivity : ComponentActivity() {
    private lateinit var store: PresetStore
    private lateinit var runtime: TimerRuntimeStore
    private lateinit var settings: AppSettings

    private val running = mutableStateOf(false)
    private val elapsed = mutableIntStateOf(0)
    private val selected = mutableIntStateOf(0)
    private val presetsState = mutableStateOf<List<TimerPreset>>(emptyList())
    private val screenMode = mutableStateOf(ScreenMode.WHILE_RUNNING)
    private val phoneLinked = mutableStateOf(false)

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ShakeTimerService.ACTION_STATE_CHANGED) return
            running.value = intent.getBooleanExtra("running", false)
            elapsed.intValue = intent.getIntExtra("elapsed", 0)
            selected.intValue = intent.getIntExtra("preset", 0).coerceIn(0, 3)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = PresetStore(this)
        runtime = TimerRuntimeStore(this)
        settings = AppSettings(this)
        presetsState.value = store.load()
        selected.intValue = runtime.selectedPreset()
        running.value = runtime.isRunning()
        elapsed.intValue = currentElapsed()
        screenMode.value = settings.screenMode()
        phoneLinked.value = settings.phoneLinked()

        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 301)
        }
        ContextCompat.startForegroundService(this, Intent(this, ShakeTimerService::class.java))
        if (phoneLinked.value) requestPhoneOpen()
        setContent { WatchApp() }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ShakeTimerService.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(stateReceiver, filter)
    }

    override fun onStop() {
        unregisterReceiver(stateReceiver)
        super.onStop()
    }

    private fun currentElapsed(): Int = if (!runtime.isRunning()) 0 else
        ((System.currentTimeMillis() - runtime.wallStartedAt()) / 1000L).coerceAtLeast(0L).toInt()

    private fun toggle() {
        ContextCompat.startForegroundService(this, Intent(this, ShakeTimerService::class.java).setAction(ShakeTimerService.ACTION_TOGGLE))
    }

    private fun exitApp() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, ShakeTimerService::class.java).setAction(ShakeTimerService.ACTION_EXIT_APP)
        )
        finishAndRemoveTask()
    }

    private fun selectPreset(index: Int) {
        selected.intValue = index.coerceIn(0, 3)
        runtime.setSelectedPreset(selected.intValue)
        if (phoneLinked.value) syncState()
    }

    private fun applyScreenMode() {
        val keepOn = screenMode.value == ScreenMode.ALWAYS ||
            (screenMode.value == ScreenMode.WHILE_RUNNING && running.value)
        if (keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun saveScreenMode(mode: ScreenMode) {
        screenMode.value = mode
        settings.setScreenMode(mode)
        applyScreenMode()
    }

    private fun saveLinkMode(linked: Boolean) {
        phoneLinked.value = linked
        settings.setPhoneLinked(linked)
        val req = PutDataMapRequest.create("/link_control").apply {
            dataMap.putBoolean("linked", linked)
            dataMap.putBoolean("open_phone", linked)
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
        if (linked) syncState()
    }

    private fun requestPhoneOpen() {
        val req = PutDataMapRequest.create("/link_control").apply {
            dataMap.putBoolean("linked", true)
            dataMap.putBoolean("open_phone", true)
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
        syncState()
    }

    private fun syncState() {
        val req = PutDataMapRequest.create("/timer_state").apply {
            dataMap.putBoolean("running", runtime.isRunning())
            dataMap.putLong("wall_started_at", if (runtime.isRunning()) runtime.wallStartedAt() else 0L)
            dataMap.putInt("preset", runtime.selectedPreset())
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    private fun savePreset(index: Int, preset: TimerPreset) {
        store.save(index, preset)
        presetsState.value = store.load()
        if (!phoneLinked.value) return
        val all = presetsState.value
        val req = PutDataMapRequest.create("/presets").apply {
            all.forEachIndexed { i, p ->
                dataMap.putString("name_$i", p.name)
                dataMap.putInt("a_$i", p.firstSec)
                dataMap.putInt("b_$i", p.secondSec)
                dataMap.putInt("c_$i", p.thirdSec)
            }
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    @Composable private fun WatchApp() {
        var page by remember { mutableIntStateOf(0) }
        LaunchedEffect(screenMode.value, running.value) { applyScreenMode() }
        BackHandler(enabled = page != 0) { page = 0 }
        when (page) {
            1 -> PresetEditor(onBack = { page = 0 })
            2 -> SensitivityEditor(onBack = { page = 0 })
            3 -> VibrationEditor(onBack = { page = 0 })
            4 -> ScreenEditor(onBack = { page = 0 })
            5 -> LinkEditor(onBack = { page = 0 })
            else -> TimerScreen(
                onEdit = { page = 1 },
                onSensitivity = { page = 2 },
                onVibration = { page = 3 },
                onScreen = { page = 4 },
                onLink = { page = 5 }
            )
        }
    }

    @Composable private fun TimerScreen(
        onEdit: () -> Unit,
        onSensitivity: () -> Unit,
        onVibration: () -> Unit,
        onScreen: () -> Unit,
        onLink: () -> Unit
    ) {
        val presets = presetsState.value.ifEmpty { Defaults.presets }
        val preset = presets[selected.intValue.coerceIn(presets.indices)]
        val stage = preset.stageAt(elapsed.intValue)
        val bg = when (stage) {
            Stage.NORMAL -> Color.Black
            Stage.FIRST -> Color(0xFFFFEB3B)
            Stage.SECOND -> Color(0xFFFF9800)
            Stage.THIRD -> Color(0xFFF44336)
        }
        val fg = if (stage == Stage.NORMAL) Color.White else Color.Black

        Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.timer_billiards_bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.34f
            )
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("군호TV 타이머", color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("%02d:%02d".format(elapsed.intValue / 60, elapsed.intValue % 60), color = fg, fontSize = 43.sp, fontWeight = FontWeight.Black)
                Text("${preset.firstSec} · ${preset.secondSec} · ${preset.thirdSec}", color = fg, fontSize = 11.sp)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { toggle() }, modifier = Modifier.size(43.dp)) {
                        Text(if (running.value) "정지" else "시작", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onScreen,
                        modifier = Modifier.size(49.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = when (screenMode.value) {
                                ScreenMode.ALWAYS -> Color(0xFF1E8E3E)
                                ScreenMode.WHILE_RUNNING -> Color(0xFFC62828)
                                ScreenMode.SYSTEM -> Color(0xFFF9A825)
                            },
                            contentColor = Color.White
                        )
                    ) { Text("화면", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = { exitApp() },
                        modifier = Modifier.size(43.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8E2430), contentColor = Color.White)
                    ) { Text("종료", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    repeat(4) { i ->
                        Button(onClick = { selectPreset(i) }, modifier = Modifier.size(33.dp)) {
                            Text("${i + 1}", fontSize = 10.sp, fontWeight = if (i == selected.intValue) FontWeight.Black else FontWeight.Normal)
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(onClick = onEdit, modifier = Modifier.size(39.dp)) { Text("시간", fontSize = 9.sp) }
                    Button(onClick = onSensitivity, modifier = Modifier.size(39.dp)) { Text("감도", fontSize = 9.sp) }
                    Button(onClick = onVibration, modifier = Modifier.size(39.dp)) { Text("진동", fontSize = 9.sp) }
                    Button(
                        onClick = onLink,
                        modifier = Modifier.size(39.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = if (phoneLinked.value) Color(0xFF1565C0) else Color(0xFF5F6368),
                            contentColor = Color.White
                        )
                    ) { Text("연동", fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }

    @Composable private fun ScreenEditor(onBack: () -> Unit) {
        val optionColors = mapOf(
            ScreenMode.ALWAYS to Color(0xFF1E8E3E),
            ScreenMode.WHILE_RUNNING to Color(0xFFC62828),
            ScreenMode.SYSTEM to Color(0xFFF9A825)
        )
        Column(
            modifier = Modifier.fillMaxSize().background(Color.Black)
                .verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text("화면 유지", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            ScreenMode.entries.forEach { mode ->
                Button(
                    onClick = { saveScreenMode(mode); onBack() },
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    colors = ButtonDefaults.buttonColors(backgroundColor = optionColors.getValue(mode), contentColor = Color.White)
                ) { Text(if (screenMode.value == mode) "✓ ${mode.label}" else mode.label, fontSize = 12.sp) }
            }
            Text("계속 지속: 항상 켜짐\n작동 시만: 타이머 중 켜짐\n꺼짐: 워치 자동 꺼짐 사용", fontSize = 9.sp)
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth().height(32.dp)) { Text("뒤로", fontSize = 10.sp) }
        }
    }

    @Composable private fun LinkEditor(onBack: () -> Unit) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color.Black)
                .verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text("휴대폰 연동", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { saveLinkMode(true); onBack() },
                modifier = Modifier.fillMaxWidth().height(38.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF1565C0), contentColor = Color.White)
            ) { Text(if (phoneLinked.value) "✓ 함께 동작" else "함께 동작", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            Text("워치 실행 시 휴대폰 앱을 열고\n시작·정지·시간을 같이 맞춥니다", fontSize = 9.sp)
            Button(
                onClick = { saveLinkMode(false); onBack() },
                modifier = Modifier.fillMaxWidth().height(38.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF5F6368), contentColor = Color.White)
            ) { Text(if (!phoneLinked.value) "✓ 별도로 사용" else "별도로 사용", fontSize = 12.sp) }
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth().height(32.dp)) { Text("뒤로", fontSize = 10.sp) }
        }
    }

    @Composable private fun VibrationEditor(onBack: () -> Unit) {
        var counts by remember { mutableStateOf((1..3).map { settings.vibrationCount(it) }) }
        var long by remember { mutableStateOf(settings.longVibration()) }
        val player = remember { AlertPlayer(this@WearMainActivity) }
        Column(
            modifier = Modifier.fillMaxSize().background(Color.Black)
                .verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("진동 설정", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("눌러서 횟수 변경", fontSize = 10.sp)
            counts.forEachIndexed { index, count ->
                Button(onClick = {
                    counts = counts.toMutableList().also { it[index] = count % 3 + 1 }
                }, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                    Text("${index + 1}차 알림 · ${count}회", fontSize = 12.sp)
                }
            }
            Button(onClick = { long = !long }, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                Text(if (long) "길게 울림 · 켜짐" else "길게 울림 · 꺼짐", fontSize = 11.sp)
            }
            Text("각 알림의 횟수와 길이\n모든 프리셋에 적용", fontSize = 10.sp)
            Button(onClick = { player.previewVibration(counts[0], long) }, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                Text("1차 진동 미리듣기", fontSize = 11.sp)
            }
            Text("테스트는 무음에서도 진동", fontSize = 9.sp)
            Button(onClick = { settings.saveVibration(counts, long); onBack() }, modifier = Modifier.fillMaxWidth().height(40.dp)) {
                Text("저장", fontSize = 12.sp)
            }
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth().height(40.dp)) { Text("취소", fontSize = 12.sp) }
        }
    }

    @Composable private fun PresetEditor(onBack: () -> Unit) {
        val presets = presetsState.value.ifEmpty { Defaults.presets }
        val base = presets[selected.intValue]
        var a by remember(base) { mutableIntStateOf(base.firstSec) }
        var b by remember(base) { mutableIntStateOf(base.secondSec) }
        var c by remember(base) { mutableIntStateOf(base.thirdSec) }
        var field by remember { mutableIntStateOf(0) }
        val values = listOf(a, b, c)

        Box(Modifier.fillMaxSize().background(Color.Black).padding(8.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("프리셋 ${selected.intValue + 1}", fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    repeat(3) { i -> Button(onClick = { field = i }, modifier = Modifier.height(32.dp)) { Text("${i + 1}차", fontSize = 9.sp) } }
                }
                Text("${values[field]}초", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        when (field) { 0 -> a = (a - 1).coerceAtLeast(1); 1 -> b = (b - 1).coerceAtLeast(a + 1); 2 -> c = (c - 1).coerceAtLeast(b + 1) }
                    }, modifier = Modifier.size(42.dp)) { Text("−") }
                    Button(onClick = {
                        when (field) { 0 -> a = (a + 1).coerceAtMost(b - 1); 1 -> b = (b + 1).coerceAtMost(c - 1); 2 -> c += 1 }
                    }, modifier = Modifier.size(42.dp)) { Text("+") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(onClick = onBack, modifier = Modifier.height(32.dp)) { Text("취소", fontSize = 9.sp) }
                    Button(onClick = { savePreset(selected.intValue, TimerPreset(base.name, a, b, c)); onBack() }, modifier = Modifier.height(32.dp)) { Text("저장", fontSize = 9.sp) }
                }
            }
        }
    }

    @Composable private fun SensitivityEditor(onBack: () -> Unit) {
        var sensitivity by remember { mutableStateOf(settings.sensitivity()) }
        Box(Modifier.fillMaxSize().background(Color.Black).padding(10.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("흔들기 감도", fontSize = 16.sp)
                ShakeSensitivity.entries.forEach { item ->
                    Button(onClick = { sensitivity = item }, modifier = Modifier.fillMaxWidth(0.72f).height(36.dp)) {
                        Text(if (item == sensitivity) "✓ ${item.label}" else item.label, fontSize = 11.sp)
                    }
                }
                Button(onClick = {
                    settings.setSensitivity(sensitivity)
                    ContextCompat.startForegroundService(this@WearMainActivity, Intent(this@WearMainActivity, ShakeTimerService::class.java).setAction(ShakeTimerService.ACTION_REFRESH_SETTINGS))
                    onBack()
                }, modifier = Modifier.height(34.dp)) { Text("저장", fontSize = 10.sp) }
            }
        }
    }
}

