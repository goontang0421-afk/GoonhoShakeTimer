# 군호TV 흔들기 타이머 v5

v3 기능을 유지하면서 실제 사용 UI 시안의 분위기를 앱 타이머 화면에 반영한 버전입니다.

## v4 변경점
- 폰/갤럭시 워치 타이머 배경에 군호TV 당구 테마 실사용 이미지 적용
- 중앙 브랜드는 `군호TV`만 표시
- 타이머 숫자 가독성을 위해 배경 이미지는 낮은 투명도로 처리
- 20초 노랑 / 27초 주황 / 35초 빨강 단계 색상은 기존대로 유지
- 5개 프리셋, 흔들기 감도, 화면 꺼짐 감지, 폰↔워치 동기화 유지
- PBA Helix Vision 스타일의 노랑/빨강/흰색 3쿠션 공 비주얼을 배경 자산으로 사용

## 기본 프리셋
20초 / 27초 / 35초

Android Studio에서 프로젝트를 열어 mobile 및 wear 모듈을 빌드하세요.

## v5 실제 APK 자동 빌드
이 프로젝트에는 `.github/workflows/build-apk.yml`이 포함되어 있습니다.
`main`에 push하거나 pull request를 열면 **Build APKs**가 실행됩니다. Actions에서 수동 실행도 가능합니다.
성공한 실행의 Artifacts에서 다음 두 ZIP을 다운로드하고 압축을 풀어 설치하세요.
- `GoonhoShakeTimer-Phone`: `GoonhoShakeTimer-Phone.apk` (Android 8.0 이상)
- `GoonhoShakeTimer-Watch`: `GoonhoShakeTimer-Watch.apk` (Android API 30 이상 Wear OS)

빌드 환경: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Android SDK 35.
로컬에서는 Gradle 8.9를 설치하고 `gradle :mobile:assembleDebug :wear:assembleDebug`를 실행하세요.

두 APK는 같은 작업에서 같은 디버그 서명 키로 빌드됩니다. 폰과 워치에는 같은 실행에서 받은 APK 쌍을 설치하세요.
Actions의 새 실행은 디버그 키가 달라질 수 있으므로 기존 설치와 서명이 다르면 앱 삭제 후 재설치가 필요합니다.
삭제 시 저장된 설정도 삭제됩니다. 이 빌드는 개인 테스트용이며 Play Store 배포용 릴리스 서명은 포함하지 않습니다.

실제 기기에서 흔들기 감도, 화면 꺼짐 중 알림, 폰과 워치 동기화는 별도 확인이 필요합니다.
현재 휴대폰의 센서 감지는 Activity가 활성화된 동안 동작하고 워치는 포그라운드 서비스를 사용합니다.
