package tv.goonho.shaketimer

import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.wearable.*
import kotlinx.coroutines.delay
import tv.goonho.shaketimer.shared.*

class MainActivity : ComponentActivity(), DataClient.OnDataChangedListener {
    private lateinit var sensorManager: SensorManager
    private var detector: ShakeDetector? = null
    private lateinit var alert: AlertPlayer
    private lateinit var store: PresetStore
    private lateinit var settings: AppSettings

    private val running = mutableStateOf(false)
    private val startedAt = mutableLongStateOf(0L)
    private val selected = mutableIntStateOf(0)
    private val remoteElapsed = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        alert = AlertPlayer(this)
        store = PresetStore(this)
        settings = AppSettings(this)
        detector = ShakeDetector(thresholdG = settings.sensitivity().thresholdG) { toggleTimer(true) }
        setContent { TimerApp() }
    }

    override fun onResume() {
        super.onResume()
        Wearable.getDataClient(this).addListener(this)
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(detector, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        Wearable.getDataClient(this).removeListener(this)
        sensorManager.unregisterListener(detector)
    }

    private fun toggleTimer(sync: Boolean) {
        if (running.value) {
            running.value = false; startedAt.longValue = 0L; remoteElapsed.intValue = 0
        } else {
            startedAt.longValue = SystemClock.elapsedRealtime(); running.value = true
        }
        if (sync) syncState()
    }

    private fun syncPresets(presets: List<TimerPreset>) {
        val req = PutDataMapRequest.create("/presets").apply {
            presets.forEachIndexed { i, p ->
                dataMap.putString("name_$i", p.name)
                dataMap.putInt("a_$i", p.firstSec)
                dataMap.putInt("b_$i", p.secondSec)
                dataMap.putInt("c_$i", p.thirdSec)
            }
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    private fun syncState() {
        val req = PutDataMapRequest.create("/timer_state").apply {
            dataMap.putBoolean("running", running.value)
            dataMap.putLong("wall_started_at", if (running.value) System.currentTimeMillis() else 0L)
            dataMap.putInt("preset", selected.intValue)
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    override fun onDataChanged(buffer: DataEventBuffer) {
        buffer.forEach { event ->
            if (event.type == DataEvent.TYPE_CHANGED && event.dataItem.uri.path == "/timer_state") {
                val m = DataMapItem.fromDataItem(event.dataItem).dataMap
                val isRunning = m.getBoolean("running")
                selected.intValue = m.getInt("preset")
                if (isRunning) {
                    val wall = m.getLong("wall_started_at")
                    val elapsed = ((System.currentTimeMillis() - wall) / 1000).coerceAtLeast(0).toInt()
                    startedAt.longValue = SystemClock.elapsedRealtime() - elapsed * 1000L
                    running.value = true
                } else {
                    running.value = false; startedAt.longValue = 0L
                }
            }
        }
    }

    @Composable private fun TimerApp() {
        var presets by remember { mutableStateOf(store.load()) }
        var elapsed by remember { mutableIntStateOf(0) }
        var lastAlert by remember { mutableIntStateOf(0) }
        var editing by remember { mutableStateOf(false) }
        var editingSensitivity by remember { mutableStateOf(false) }
        val preset = presets[selected.intValue]

        LaunchedEffect(running.value, startedAt.longValue) {
            if (!running.value) { elapsed = 0; lastAlert = 0; return@LaunchedEffect }
            while (running.value) {
                elapsed = ((SystemClock.elapsedRealtime() - startedAt.longValue) / 1000L).toInt()
                val level = when {
                    elapsed >= preset.thirdSec -> 3
                    elapsed >= preset.secondSec -> 2
                    elapsed >= preset.firstSec -> 1
                    else -> 0
                }
                if (level > lastAlert) { alert.alert(level); lastAlert = level }
                delay(100)
            }
        }

        val bg = when (preset.stageAt(elapsed)) {
            Stage.NORMAL -> Color.Black
            Stage.FIRST -> Color(0xFFFFEB3B)
            Stage.SECOND -> Color(0xFFFF9800)
            Stage.THIRD -> Color(0xFFF44336)
        }
        val fg = if (preset.stageAt(elapsed) == Stage.NORMAL) Color.White else Color.Black

        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(R.drawable.timer_billiards_bg),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.24f
                )
                Text(
                    "군호TV",
                    color = fg.copy(alpha = 0.10f),
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.align(Alignment.Center)
                )
                Column(
                    modifier = Modifier.fillMaxSize().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                Text("군호 흔들기 타이머", color=fg, fontSize=20.sp, fontWeight=FontWeight.Bold)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("%02d:%02d".format(elapsed/60, elapsed%60), color=fg, fontSize=76.sp, fontWeight=FontWeight.Black)
                    Text(preset.name, color=fg, fontSize=18.sp)
                    Text("${preset.firstSec}초 · ${preset.secondSec}초 · ${preset.thirdSec}초", color=fg)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick={ toggleTimer(true) }) { Text(if (running.value) "정지 / 초기화" else "시작") }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        presets.indices.forEach { i ->
                            OutlinedButton(onClick={ selected.intValue=i; syncState() }, contentPadding=PaddingValues(horizontal=12.dp)) { Text("${i+1}") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick={ editing = true }) { Text("프리셋 편집") }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick={ editingSensitivity = true }) { Text("흔들기 감도: ${settings.sensitivity().label}") }
                    Spacer(Modifier.height(8.dp))
                    Text("워치: 손목을 흔들어 시작 · 다시 흔들어 정지", color=fg, fontSize=14.sp)
                }
                }
            }
        }

        if (editing) {
            var name by remember(preset, editing) { mutableStateOf(preset.name) }
            var a by remember(preset, editing) { mutableStateOf(preset.firstSec.toString()) }
            var b by remember(preset, editing) { mutableStateOf(preset.secondSec.toString()) }
            var c by remember(preset, editing) { mutableStateOf(preset.thirdSec.toString()) }
            AlertDialog(
                onDismissRequest = { editing = false },
                title = { Text("프리셋 ${selected.intValue + 1} 편집") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value=name, onValueChange={name=it}, label={Text("이름")}, singleLine=true)
                        OutlinedTextField(value=a, onValueChange={a=it.filter(Char::isDigit)}, label={Text("1차 알림(초)")}, singleLine=true)
                        OutlinedTextField(value=b, onValueChange={b=it.filter(Char::isDigit)}, label={Text("2차 알림(초)")}, singleLine=true)
                        OutlinedTextField(value=c, onValueChange={c=it.filter(Char::isDigit)}, label={Text("3차 알림(초)")}, singleLine=true)
                    }
                },
                confirmButton = {
                    TextButton(onClick={
                        val aa=a.toIntOrNull() ?: preset.firstSec
                        val bb=b.toIntOrNull() ?: preset.secondSec
                        val cc=c.toIntOrNull() ?: preset.thirdSec
                        if (aa < bb && bb < cc) {
                            val updated = TimerPreset(name.ifBlank { "프리셋 ${selected.intValue+1}" }, aa, bb, cc)
                            store.save(selected.intValue, updated)
                            presets = presets.toMutableList().also { it[selected.intValue] = updated }
                            syncPresets(presets)
                            editing = false
                        }
                    }) { Text("저장") }
                },
                dismissButton = { TextButton(onClick={editing=false}) { Text("취소") } }
            )
        }
        if (editingSensitivity) {
            var sensitivity by remember { mutableStateOf(settings.sensitivity()) }
            AlertDialog(
                onDismissRequest = { editingSensitivity = false },
                title = { Text("흔들기 감도") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ShakeSensitivity.entries.forEach { item ->
                            Button(onClick = { sensitivity = item }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (item == sensitivity) "✓ ${item.label}" else item.label)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        settings.setSensitivity(sensitivity)
                        detector?.setThreshold(sensitivity.thresholdG)
                        editingSensitivity = false
                    }) { Text("저장") }
                },
                dismissButton = { TextButton(onClick = { editingSensitivity = false }) { Text("취소") } }
            )
        }

    }
}
