package tv.goonho.shaketimer

import android.hardware.Sensor
import android.hardware.SensorManager
import android.Manifest
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import com.google.android.gms.wearable.*
import kotlinx.coroutines.delay
import tv.goonho.shaketimer.shared.*

class MainActivity : ComponentActivity(), DataClient.OnDataChangedListener {
    private lateinit var sensorManager: SensorManager
    private var detector: ShakeDetector? = null
    private lateinit var alert: AlertPlayer
    private lateinit var store: PresetStore
    private lateinit var settings: AppSettings
    private lateinit var runtime: TimerRuntimeStore

    private val running = mutableStateOf(false)
    private val startedAt = mutableLongStateOf(0L)
    private val selected = mutableIntStateOf(0)
    private val remoteElapsed = mutableIntStateOf(0)
    private val screenMode = mutableStateOf(ScreenMode.WHILE_RUNNING)
    private val phoneLinked = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        alert = AlertPlayer(this)
        store = PresetStore(this)
        settings = AppSettings(this)
        runtime = TimerRuntimeStore(this)
        selected.intValue = runtime.selectedPreset()
        running.value = runtime.isRunning()
        screenMode.value = settings.screenMode()
        phoneLinked.value = settings.phoneLinked()
        if (running.value) {
            val elapsed = ((System.currentTimeMillis() - runtime.wallStartedAt()) / 1000L).coerceAtLeast(0L)
            startedAt.longValue = SystemClock.elapsedRealtime() - elapsed * 1000L
        }
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 401)
        }
        getSystemService(NotificationManager::class.java).cancel(MobileSyncService.OPEN_NOTIFICATION_ID)
        detector = ShakeDetector(thresholdG = settings.sensitivity().thresholdG) { toggleTimer(true) }
        setContent { TimerApp() }
    }

    override fun onResume() {
        super.onResume()
        selected.intValue = runtime.selectedPreset()
        screenMode.value = settings.screenMode()
        phoneLinked.value = settings.phoneLinked()
        if (runtime.isRunning()) {
            val elapsed = ((System.currentTimeMillis() - runtime.wallStartedAt()) / 1000L).coerceAtLeast(0L)
            startedAt.longValue = SystemClock.elapsedRealtime() - elapsed * 1000L
            running.value = true
        } else {
            running.value = false
            startedAt.longValue = 0L
        }
        Wearable.getDataClient(this).addListener(this)
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(detector, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        Wearable.getDataClient(this).removeListener(this)
        sensorManager.unregisterListener(detector)
    }

    private fun toggleTimer(sync: Boolean) {
        if (running.value) {
            running.value = false; startedAt.longValue = 0L; remoteElapsed.intValue = 0; runtime.stop()
        } else {
            startedAt.longValue = SystemClock.elapsedRealtime(); running.value = true; runtime.start()
        }
        if (sync && phoneLinked.value) syncState()
    }

    private fun applyScreenMode() {
        val keepOn = screenMode.value == ScreenMode.ALWAYS ||
            (screenMode.value == ScreenMode.WHILE_RUNNING && running.value)
        if (keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun saveScreenMode(mode: ScreenMode) {
        screenMode.value = mode
        settings.setScreenMode(mode)
        applyScreenMode()
    }

    private fun saveLinkMode(linked: Boolean) {
        phoneLinked.value = linked
        settings.setPhoneLinked(linked)
        val req = PutDataMapRequest.create("/link_control").apply {
            dataMap.putBoolean("linked", linked)
            dataMap.putBoolean("open_phone", false)
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
        if (linked) syncState()
    }

    private fun exitApp() {
        if (running.value) toggleTimer(true)
        finishAndRemoveTask()
    }

    private fun syncPresets(presets: List<TimerPreset>) {
        if (!phoneLinked.value) return
        val req = PutDataMapRequest.create("/presets").apply {
            presets.forEachIndexed { i, p ->
                dataMap.putString("name_$i", p.name)
                dataMap.putInt("a_$i", p.firstSec)
                dataMap.putInt("b_$i", p.secondSec)
                dataMap.putInt("c_$i", p.thirdSec)
            }
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    private fun syncState() {
        val req = PutDataMapRequest.create("/timer_state").apply {
            dataMap.putBoolean("running", running.value)
            dataMap.putLong("wall_started_at", if (running.value) runtime.wallStartedAt() else 0L)
            dataMap.putInt("preset", selected.intValue)
            dataMap.putLong("nonce", System.nanoTime())
        }.asPutDataRequest().setUrgent()
        Wearable.getDataClient(this).putDataItem(req)
    }

    override fun onDataChanged(buffer: DataEventBuffer) {
        buffer.forEach { event ->
            if (event.type != DataEvent.TYPE_CHANGED) return@forEach
            val m = DataMapItem.fromDataItem(event.dataItem).dataMap
            if (event.dataItem.uri.path == "/link_control") {
                phoneLinked.value = m.getBoolean("linked")
                settings.setPhoneLinked(phoneLinked.value)
            }
            if (event.dataItem.uri.path == "/timer_state" && settings.phoneLinked()) {
                val isRunning = m.getBoolean("running")
                selected.intValue = m.getInt("preset").coerceIn(0, 3)
                runtime.setSelectedPreset(selected.intValue)
                if (isRunning) {
                    val wall = m.getLong("wall_started_at")
                    val elapsed = ((System.currentTimeMillis() - wall) / 1000).coerceAtLeast(0).toInt()
                    startedAt.longValue = SystemClock.elapsedRealtime() - elapsed * 1000L
                    running.value = true
                    runtime.start(wall)
                } else {
                    running.value = false; startedAt.longValue = 0L; runtime.stop()
                }
            }
        }
    }

    @Composable private fun TimerApp() {
        var presets by remember { mutableStateOf(store.load()) }
        var elapsed by remember { mutableIntStateOf(0) }
        var lastAlert by remember { mutableIntStateOf(0) }
        var editing by remember { mutableStateOf(false) }
        var editingSensitivity by remember { mutableStateOf(false) }
        var editingVibration by remember { mutableStateOf(false) }
        var editingScreen by remember { mutableStateOf(false) }
        var editingLink by remember { mutableStateOf(false) }
        val preset = presets[selected.intValue]

        LaunchedEffect(screenMode.value, running.value) { applyScreenMode() }

        LaunchedEffect(running.value, startedAt.longValue) {
            if (!running.value) { elapsed = 0; lastAlert = 0; return@LaunchedEffect }
            while (running.value) {
                elapsed = ((SystemClock.elapsedRealtime() - startedAt.longValue) / 1000L).toInt()
                val level = when {
                    elapsed >= preset.thirdSec -> 3
                    elapsed >= preset.secondSec -> 2
                    elapsed >= preset.firstSec -> 1
                    else -> 0
                }
                if (level > lastAlert) { alert.alert(level); lastAlert = level }
                delay(100)
            }
        }

        val bg = when (preset.stageAt(elapsed)) {
            Stage.NORMAL -> Color.Black
            Stage.FIRST -> Color(0xFFFFEB3B)
            Stage.SECOND -> Color(0xFFFF9800)
            Stage.THIRD -> Color(0xFFF44336)
        }
        val fg = if (preset.stageAt(elapsed) == Stage.NORMAL) Color.White else Color.Black

        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(R.drawable.timer_billiards_bg),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.24f
                )
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                Text("흔들어 시작 · 다시 흔들어 정지", color=fg, fontSize=13.sp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("군호TV 타이머", color=fg, fontSize=28.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("%02d:%02d".format(elapsed/60, elapsed%60), color=fg, fontSize=76.sp, fontWeight=FontWeight.Black)
                    Text(preset.name, color=fg, fontSize=18.sp)
                    Text("${preset.firstSec}초 · ${preset.secondSec}초 · ${preset.thirdSec}초", color=fg)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick={ toggleTimer(true) }, modifier = Modifier.width(94.dp)) {
                            Text(if (running.value) "정지" else "시작", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick={ editingScreen = true },
                            modifier = Modifier.width(94.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = when (screenMode.value) {
                                ScreenMode.ALWAYS -> Color(0xFF1E8E3E)
                                ScreenMode.WHILE_RUNNING -> Color(0xFFC62828)
                                ScreenMode.SYSTEM -> Color(0xFFF9A825)
                            })
                        ) { Text("화면", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick={ exitApp() },
                            modifier = Modifier.width(94.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E2430))
                        ) { Text("종료", fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        (0 until minOf(4, presets.size)).forEach { i ->
                            OutlinedButton(onClick={ selected.intValue=i; runtime.setSelectedPreset(i); if (settings.phoneLinked()) syncState() }, contentPadding=PaddingValues(horizontal=12.dp)) { Text("${i+1}") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={ editing = true }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("시간") }
                        OutlinedButton(onClick={ editingSensitivity = true }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("감도") }
                        OutlinedButton(onClick={ editingVibration = true }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("진동") }
                        Button(
                            onClick={ editingLink = true },
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (phoneLinked.value) Color(0xFF1565C0) else Color(0xFF5F6368))
                        ) { Text("연동", fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(if (phoneLinked.value) "워치와 함께 동작 중" else "휴대폰에서 별도로 동작 중", color=fg, fontSize=13.sp)
                }
                }
            }
        }

        if (editing) {
            var name by remember(preset, editing) { mutableStateOf(preset.name) }
            var a by remember(preset, editing) { mutableStateOf(preset.firstSec.toString()) }
            var b by remember(preset, editing) { mutableStateOf(preset.secondSec.toString()) }
            var c by remember(preset, editing) { mutableStateOf(preset.thirdSec.toString()) }
            AlertDialog(
                onDismissRequest = { editing = false },
                title = { Text("프리셋 ${selected.intValue + 1} 편집") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value=name, onValueChange={name=it}, label={Text("이름")}, singleLine=true)
                        OutlinedTextField(value=a, onValueChange={a=it.filter(Char::isDigit)}, label={Text("1차 알림(초)")}, singleLine=true)
                        OutlinedTextField(value=b, onValueChange={b=it.filter(Char::isDigit)}, label={Text("2차 알림(초)")}, singleLine=true)
                        OutlinedTextField(value=c, onValueChange={c=it.filter(Char::isDigit)}, label={Text("3차 알림(초)")}, singleLine=true)
                    }
                },
                confirmButton = {
                    TextButton(onClick={
                        val aa=a.toIntOrNull() ?: preset.firstSec
                        val bb=b.toIntOrNull() ?: preset.secondSec
                        val cc=c.toIntOrNull() ?: preset.thirdSec
                        if (aa < bb && bb < cc) {
                            val updated = TimerPreset(name.ifBlank { "프리셋 ${selected.intValue+1}" }, aa, bb, cc)
                            store.save(selected.intValue, updated)
                            presets = presets.toMutableList().also { it[selected.intValue] = updated }
                            syncPresets(presets)
                            editing = false
                        }
                    }) { Text("저장") }
                },
                dismissButton = { TextButton(onClick={editing=false}) { Text("취소") } }
            )
        }
        if (editingSensitivity) {
            var sensitivity by remember { mutableStateOf(settings.sensitivity()) }
            AlertDialog(
                onDismissRequest = { editingSensitivity = false },
                title = { Text("흔들기 감도") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ShakeSensitivity.entries.forEach { item ->
                            Button(onClick = { sensitivity = item }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (item == sensitivity) "✓ ${item.label}" else item.label)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        settings.setSensitivity(sensitivity)
                        detector?.setThreshold(sensitivity.thresholdG)
                        editingSensitivity = false
                    }) { Text("저장") }
                },
                dismissButton = { TextButton(onClick = { editingSensitivity = false }) { Text("취소") } }
            )
        }

        if (editingVibration) {
            var counts by remember { mutableStateOf((1..3).map { settings.vibrationCount(it) }) }
            var long by remember { mutableStateOf(settings.longVibration()) }
            AlertDialog(
                onDismissRequest = { editingVibration = false },
                title = { Text("휴대폰 진동 설정") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("모든 프리셋에 적용됩니다. 워치는 워치의 진동 메뉴에서 설정하세요.")
                        counts.forEachIndexed { index, count ->
                            OutlinedButton(onClick = {
                                counts = counts.toMutableList().also { it[index] = count % 3 + 1 }
                            }, modifier = Modifier.fillMaxWidth()) { Text("${index + 1}차 알림 · ${count}회") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("길게 울림", modifier = Modifier.weight(1f))
                            Switch(checked = long, onCheckedChange = { long = it })
                        }
                        TextButton(onClick = { alert.previewVibration(counts[0], long) }) { Text("1차 진동 테스트 (무음에서도 진동)") }
                    }
                },
                confirmButton = { TextButton(onClick = {
                    settings.saveVibration(counts, long)
                    editingVibration = false
                }) { Text("저장") } },
                dismissButton = { TextButton(onClick = { editingVibration = false }) { Text("취소") } }
            )
        }

        if (editingScreen) {
            AlertDialog(
                onDismissRequest = { editingScreen = false },
                title = { Text("화면 유지") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScreenMode.entries.forEach { mode ->
                            Button(
                                onClick = { saveScreenMode(mode); editingScreen = false },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = when (mode) {
                                    ScreenMode.ALWAYS -> Color(0xFF1E8E3E)
                                    ScreenMode.WHILE_RUNNING -> Color(0xFFC62828)
                                    ScreenMode.SYSTEM -> Color(0xFFF9A825)
                                })
                            ) { Text(if (screenMode.value == mode) "✓ ${mode.label}" else mode.label) }
                        }
                        Text("계속 지속: 항상 켜짐\n작동 시만 지속: 타이머 중 켜짐\n꺼짐: 휴대폰 자동 꺼짐 사용")
                    }
                },
                confirmButton = { TextButton(onClick = { editingScreen = false }) { Text("닫기") } }
            )
        }

        if (editingLink) {
            AlertDialog(
                onDismissRequest = { editingLink = false },
                title = { Text("워치 연동") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { saveLinkMode(true); editingLink = false },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                        ) { Text(if (phoneLinked.value) "✓ 함께 동작" else "함께 동작", fontWeight = FontWeight.Bold) }
                        Text("워치와 같은 시작·정지·시간·프리셋으로 동작합니다.")
                        Button(
                            onClick = { saveLinkMode(false); editingLink = false },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5F6368))
                        ) { Text(if (!phoneLinked.value) "✓ 별도로 사용" else "별도로 사용") }
                    }
                },
                confirmButton = { TextButton(onClick = { editingLink = false }) { Text("닫기") } }
            )
        }

    }
}
