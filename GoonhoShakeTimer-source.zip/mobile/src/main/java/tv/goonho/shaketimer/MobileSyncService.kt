package tv.goonho.shaketimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.WearableListenerService
import tv.goonho.shaketimer.shared.AppSettings
import tv.goonho.shaketimer.shared.PresetStore
import tv.goonho.shaketimer.shared.TimerPreset
import tv.goonho.shaketimer.shared.TimerRuntimeStore

class MobileSyncService : WearableListenerService() {
    override fun onDataChanged(buffer: DataEventBuffer) {
        val settings = AppSettings(this)
        val runtime = TimerRuntimeStore(this)
        val presets = PresetStore(this)

        buffer.forEach { event ->
            if (event.type != DataEvent.TYPE_CHANGED) return@forEach
            val map = DataMapItem.fromDataItem(event.dataItem).dataMap
            when (event.dataItem.uri.path) {
                "/link_control" -> {
                    val linked = map.getBoolean("linked")
                    settings.setPhoneLinked(linked)
                    if (linked && map.getBoolean("open_phone")) openPhoneApp()
                }
                "/timer_state" -> {
                    if (!settings.phoneLinked()) return@forEach
                    runtime.setSelectedPreset(map.getInt("preset").coerceIn(0, 3))
                    if (map.getBoolean("running")) runtime.start(map.getLong("wall_started_at"))
                    else runtime.stop()
                }
                "/presets" -> if (settings.phoneLinked()) repeat(4) { i ->
                    val current = presets.load()[i]
                    presets.save(i, TimerPreset(
                        map.getString("name_$i", current.name),
                        map.getInt("a_$i", current.firstSec),
                        map.getInt("b_$i", current.secondSec),
                        map.getInt("c_$i", current.thirdSec),
                    ))
                }
            }
        }
    }

    private fun openPhoneApp() {
        createNotificationChannel()
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pending = PendingIntent.getActivity(
            this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        getSystemService(NotificationManager::class.java).notify(
            OPEN_NOTIFICATION_ID,
            NotificationCompat.Builder(this, OPEN_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_timer)
                .setContentTitle("군호TV 타이머 연동")
                .setContentText("워치와 같은 타이머를 열려면 누르세요.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pending)
                .build()
        )
        runCatching { startActivity(launch) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(OPEN_CHANNEL_ID, "워치 연동", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    companion object {
        const val OPEN_NOTIFICATION_ID = 4601
        private const val OPEN_CHANNEL_ID = "watch_link_open"
    }
}
