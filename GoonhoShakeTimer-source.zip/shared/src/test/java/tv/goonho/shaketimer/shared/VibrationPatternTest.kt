package tv.goonho.shaketimer.shared

import org.junit.Assert.assertArrayEquals
import org.junit.Test

class VibrationPatternTest {
    @Test fun defaultCountsHaveDistinctPulses() {
        assertArrayEquals(longArrayOf(0, 140), VibrationPattern.timings(1, false))
        assertArrayEquals(longArrayOf(0, 140, 120, 140), VibrationPattern.timings(2, false))
        assertArrayEquals(longArrayOf(0, 140, 120, 140, 120, 140), VibrationPattern.timings(3, false))
    }
    @Test fun longModeExtendsPulsesAndSeparatesThem() {
        assertArrayEquals(longArrayOf(0, 350, 200, 350, 200, 350), VibrationPattern.timings(3, true))
    }
    @Test fun invalidCountsCannotCreateAnUnboundedVibration() {
        assertArrayEquals(longArrayOf(0, 140), VibrationPattern.timings(-1, false))
        assertArrayEquals(VibrationPattern.timings(3, true), VibrationPattern.timings(Int.MAX_VALUE, true))
    }
}
