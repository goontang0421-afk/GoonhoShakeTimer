package tv.goonho.shaketimer.shared

import android.content.Context

class TimerRuntimeStore(context: Context) {
    private val prefs = context.getSharedPreferences("timer_runtime", Context.MODE_PRIVATE)

    fun isRunning(): Boolean = prefs.getBoolean("running", false)
    fun wallStartedAt(): Long = prefs.getLong("wall_started_at", 0L)
    fun selectedPreset(): Int = prefs.getInt("selected_preset", 0).coerceIn(0, 4)

    fun setSelectedPreset(index: Int) {
        prefs.edit().putInt("selected_preset", index.coerceIn(0, 4)).apply()
    }

    fun start(now: Long = System.currentTimeMillis()) {
        prefs.edit().putBoolean("running", true).putLong("wall_started_at", now).apply()
    }

    fun stop() {
        prefs.edit().putBoolean("running", false).putLong("wall_started_at", 0L).apply()
    }
}
