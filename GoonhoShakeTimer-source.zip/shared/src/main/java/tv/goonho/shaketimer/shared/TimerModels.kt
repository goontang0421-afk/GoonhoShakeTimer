package tv.goonho.shaketimer.shared

data class TimerPreset(
    val name: String,
    val firstSec: Int,
    val secondSec: Int,
    val thirdSec: Int,
)

data class TimerState(
    val running: Boolean = false,
    val startedAtElapsedMs: Long = 0L,
    val elapsedSec: Int = 0,
    val presetIndex: Int = 0,
)

enum class Stage { NORMAL, FIRST, SECOND, THIRD }

fun TimerPreset.stageAt(seconds: Int): Stage = when {
    seconds >= thirdSec -> Stage.THIRD
    seconds >= secondSec -> Stage.SECOND
    seconds >= firstSec -> Stage.FIRST
    else -> Stage.NORMAL
}

object Defaults {
    val presets = listOf(
        TimerPreset("기본 35초", 20, 27, 35),
        TimerPreset("프리셋 2", 10, 20, 30),
        TimerPreset("프리셋 3", 15, 25, 35),
        TimerPreset("프리셋 4", 20, 30, 40),
        TimerPreset("프리셋 5", 30, 40, 50),
    )
}
