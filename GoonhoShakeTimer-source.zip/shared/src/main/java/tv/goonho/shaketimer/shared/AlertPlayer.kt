package tv.goonho.shaketimer.shared

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlertPlayer(private val context: Context) {
    private fun vibrator(): Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java).defaultVibrator
    } else {
        @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    fun alert(count: Int) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (audio.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> Unit
            AudioManager.RINGER_MODE_VIBRATE -> vibrate(count)
            else -> sound(count)
        }
    }

    private fun vibrate(count: Int) {
        val pattern = mutableListOf<Long>(0)
        repeat(count) { pattern += 140L; pattern += 120L }
        vibrator().vibrate(VibrationEffect.createWaveform(pattern.toLongArray(), -1))
    }

    private fun sound(count: Int) {
        Thread {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            repeat(count) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                Thread.sleep(230)
            }
            tone.release()
        }.start()
    }
}
