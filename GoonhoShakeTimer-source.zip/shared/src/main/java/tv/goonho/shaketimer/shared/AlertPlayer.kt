package tv.goonho.shaketimer.shared

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlertPlayer(private val context: Context) {
    private fun vibrator(): Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        context.getSystemService(VibratorManager::class.java).defaultVibrator
    } else {
        @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    fun alert(count: Int) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (audio.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> Unit
            AudioManager.RINGER_MODE_VIBRATE -> {
                val settings = AppSettings(context)
                previewVibration(settings.vibrationCount(count), settings.longVibration())
            }
            else -> sound(count)
        }
    }

    fun previewVibration(count: Int, long: Boolean) {
        vibrator().apply {
            cancel()
            vibrate(VibrationEffect.createWaveform(VibrationPattern.timings(count, long), -1))
        }
    }

    private fun sound(count: Int) {
        Thread {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            repeat(count) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                Thread.sleep(230)
            }
            tone.release()
        }.start()
    }
}
