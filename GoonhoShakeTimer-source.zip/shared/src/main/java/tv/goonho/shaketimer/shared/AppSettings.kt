package tv.goonho.shaketimer.shared

import android.content.Context

enum class ShakeSensitivity(val label: String, val thresholdG: Float) {
    LOW("약", 2.70f),
    MEDIUM("보통", 2.35f),
    HIGH("강", 2.05f);

    companion object {
        fun fromName(value: String?): ShakeSensitivity =
            entries.firstOrNull { it.name == value } ?: MEDIUM
    }
}

enum class ScreenMode(val label: String) {
    ALWAYS("계속 지속"),
    WHILE_RUNNING("작동 시만 지속"),
    SYSTEM("꺼짐");

    companion object {
        fun fromName(value: String?): ScreenMode =
            entries.firstOrNull { it.name == value } ?: WHILE_RUNNING
    }
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    fun sensitivity(): ShakeSensitivity =
        ShakeSensitivity.fromName(prefs.getString("sensitivity", ShakeSensitivity.MEDIUM.name))

    fun setSensitivity(value: ShakeSensitivity) {
        prefs.edit().putString("sensitivity", value.name).apply()
    }

    fun screenMode(): ScreenMode =
        ScreenMode.fromName(prefs.getString("screen_mode", ScreenMode.WHILE_RUNNING.name))

    fun setScreenMode(value: ScreenMode) {
        prefs.edit().putString("screen_mode", value.name).apply()
    }

    fun phoneLinked(): Boolean = prefs.getBoolean("phone_linked", false)

    fun setPhoneLinked(value: Boolean) {
        prefs.edit().putBoolean("phone_linked", value).apply()
    }

    fun vibrationCount(stage: Int): Int =
        prefs.getInt("vibration_count_$stage", stage.coerceIn(1, 3)).coerceIn(1, 3)

    fun longVibration(): Boolean = prefs.getBoolean("long_vibration", false)

    fun saveVibration(counts: List<Int>, long: Boolean) {
        require(counts.size == 3)
        prefs.edit().apply {
            counts.forEachIndexed { index, count -> putInt("vibration_count_${index + 1}", count.coerceIn(1, 3)) }
            putBoolean("long_vibration", long)
        }.apply()
    }
}
