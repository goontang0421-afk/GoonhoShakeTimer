package tv.goonho.shaketimer.shared

import android.content.Context

enum class ShakeSensitivity(val label: String, val thresholdG: Float) {
    LOW("약", 2.70f),
    MEDIUM("보통", 2.35f),
    HIGH("강", 2.05f);

    companion object {
        fun fromName(value: String?): ShakeSensitivity =
            entries.firstOrNull { it.name == value } ?: MEDIUM
    }
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    fun sensitivity(): ShakeSensitivity =
        ShakeSensitivity.fromName(prefs.getString("sensitivity", ShakeSensitivity.MEDIUM.name))

    fun setSensitivity(value: ShakeSensitivity) {
        prefs.edit().putString("sensitivity", value.name).apply()
    }
}
