package tv.goonho.shaketimer.shared

import android.content.Context

enum class ShakeSensitivity(val label: String, val thresholdG: Float) {
    LOW("약", 2.70f),
    MEDIUM("보통", 2.35f),
    HIGH("강", 2.05f);

    companion object {
        fun fromName(value: String?): ShakeSensitivity =
            entries.firstOrNull { it.name == value } ?: MEDIUM
    }
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    fun sensitivity(): ShakeSensitivity =
        ShakeSensitivity.fromName(prefs.getString("sensitivity", ShakeSensitivity.MEDIUM.name))

    fun setSensitivity(value: ShakeSensitivity) {
        prefs.edit().putString("sensitivity", value.name).apply()
    }

    fun vibrationCount(stage: Int): Int =
        prefs.getInt("vibration_count_$stage", stage.coerceIn(1, 3)).coerceIn(1, 3)

    fun longVibration(): Boolean = prefs.getBoolean("long_vibration", false)

    fun saveVibration(counts: List<Int>, long: Boolean) {
        require(counts.size == 3)
        prefs.edit().apply {
            counts.forEachIndexed { index, count -> putInt("vibration_count_${index + 1}", count.coerceIn(1, 3)) }
            putBoolean("long_vibration", long)
        }.apply()
    }
}
