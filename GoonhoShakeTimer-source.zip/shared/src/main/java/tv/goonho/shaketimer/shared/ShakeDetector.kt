package tv.goonho.shaketimer.shared

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.os.SystemClock
import kotlin.math.sqrt

class ShakeDetector(
    thresholdG: Float = 2.35f,
    private val minGapMs: Long = 1100L,
    private val onShake: () -> Unit,
) : SensorEventListener {
    @Volatile private var thresholdG: Float = thresholdG
    private var lastShakeMs = 0L
    private var overThresholdSince = 0L

    fun setThreshold(value: Float) { thresholdG = value }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0] / GRAVITY
        val y = event.values[1] / GRAVITY
        val z = event.values[2] / GRAVITY
        val g = sqrt(x * x + y * y + z * z)
        val now = SystemClock.elapsedRealtime()

        // A very short sustained spike is required to reduce accidental triggers.
        if (g >= thresholdG) {
            if (overThresholdSince == 0L) overThresholdSince = now
            if (now - overThresholdSince >= 35L && now - lastShakeMs >= minGapMs) {
                lastShakeMs = now
                overThresholdSince = 0L
                onShake()
            }
        } else {
            overThresholdSince = 0L
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private companion object { const val GRAVITY = 9.80665f }
}
