package tv.goonho.shaketimer.shared

object VibrationPattern {
    fun timings(count: Int, long: Boolean): LongArray {
        val pulses = count.coerceIn(1, 3)
        return LongArray(pulses * 2) { index ->
            when {
                index == 0 -> 0L
                index % 2 == 1 -> if (long) 350L else 140L
                else -> if (long) 200L else 120L
            }
        }
    }
}
