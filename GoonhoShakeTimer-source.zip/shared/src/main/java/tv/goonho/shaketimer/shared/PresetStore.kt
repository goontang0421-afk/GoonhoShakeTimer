package tv.goonho.shaketimer.shared

import android.content.Context

class PresetStore(context: Context) {
    private val prefs = context.getSharedPreferences("presets", Context.MODE_PRIVATE)

    fun load(): List<TimerPreset> = Defaults.presets.mapIndexed { index, d ->
        TimerPreset(
            prefs.getString("name_$index", d.name) ?: d.name,
            prefs.getInt("a_$index", d.firstSec),
            prefs.getInt("b_$index", d.secondSec),
            prefs.getInt("c_$index", d.thirdSec),
        )
    }

    fun save(index: Int, preset: TimerPreset) {
        prefs.edit()
            .putString("name_$index", preset.name)
            .putInt("a_$index", preset.firstSec)
            .putInt("b_$index", preset.secondSec)
            .putInt("c_$index", preset.thirdSec)
            .apply()
    }
}
